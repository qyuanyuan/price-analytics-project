$(document).ready(function() {
    // datepicker
   $(".dateIn").datepicker({
       autoclose:true
   });
    // select2
    $(".se2Area").select2({});
    // 数据导入

});
